package io.xeros.content.advancedslayer;

public enum Difficulty {

    EASY, NORMAL, HARD, ANY

}
