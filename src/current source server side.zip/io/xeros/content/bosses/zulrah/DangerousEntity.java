package io.xeros.content.bosses.zulrah;

public enum DangerousEntity {
	TOXIC_SMOKE, MINION_NPC
}
