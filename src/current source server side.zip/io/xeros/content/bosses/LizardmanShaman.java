package io.xeros.content.bosses;

/**
 * Lizardman Shaman Combat Script
 * @author Matt
 */

public class LizardmanShaman {

}
