package io.xeros.content.bosses.leviathan;

/**
 * @author ArkCane
 * @social Discord: ArkCane
 * Website: www.arkcane.net
 * @since 23/03/2024
 */
public class TheLeviathan {



}
