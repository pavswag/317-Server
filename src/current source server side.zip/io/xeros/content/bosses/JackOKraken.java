package io.xeros.content.bosses;

public class JackOKraken {
}
