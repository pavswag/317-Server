package io.xeros.content.boosts;

public enum BoostType {
    EXPERIENCE, GENERIC
}
