package io.xeros.content.combat.magic;

public class StaffOfBalance {
}
